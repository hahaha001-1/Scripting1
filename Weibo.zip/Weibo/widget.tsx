import {
  HStack,
  Image,
  Link,
  Spacer,
  Text,
  VStack,
  Widget,
  fetch,
  useCallback,
  useMemo,
} from 'scripting'
import { useSettings } from './store/settings'

function WidgetView({ list }: { list: any[] }) {
  const [settings] = useSettings()
  const { height } = Widget.displaySize
  const paddingY = 12

  const standardItemHeight = settings.fontSize + settings.gap
  const count = Math.floor(
    (height - paddingY * 2 + settings.gap) / standardItemHeight
  )
  const itemHeight = standardItemHeight + (height - paddingY * 2 - standardItemHeight * count) / count
  const logoLines = settings.logoSize
    ? Math.ceil(settings.logoSize / (settings.fontSize + settings.gap))
    : 0
  const iconSize = useMemo(() => {
    const size = (settings.fontSize * 12) / 14
    return { width: size, height: size }
  }, [settings.fontSize])
  const now = new Date()

  // 小组件中自定义 scheme（weibointernational://）无法在桌面组件里直接打开，
  // 会回退启动宿主 App；统一用 https 链接，点击直接跳转 Safari 打开微博内容。
  const getItemLink = useCallback((item: any) => {
    const word = item.word || item.title || ''
    return `https://m.weibo.cn/search?containerid=${encodeURIComponent('100103type=1&t=10&q=' + word)}`
  }, [])

  // 桌面组件里自定义 scheme（weibointernational://）无法直开，会回退启动 App；
  // Logo 链接统一用 https，点击直接跳转 Safari 打开热搜页。
  const hotSearchLink = useMemo(() => {
    return `https://m.weibo.cn/p/index?containerid=${encodeURIComponent('106003&filter_type=realtimehot')}`
  }, [])

  return (
    <VStack padding={{ horizontal: 14, vertical: paddingY }} frame={Widget.displaySize} spacing={0} widgetBackground={settings.background}>
      {list.slice(0, count - logoLines).map((item, i) => (
        <HStack alignment='top'>
          <Link key={item.itemid} buttonStyle='plain' url={getItemLink(item)}>
            <HStack
              key={item.itemid}
              frame={{ height: itemHeight }}
              alignment='center'
            >
              <Text
                font={settings.fontSize}
                fontWeight='bold'
                foregroundStyle={item.itemid <= 3 ? '#fe4f67' : '#f5c94c'}
              >
                {item.itemid}
              </Text>
              <Text font={settings.fontSize} foregroundStyle={settings.color}>
                {item.title}
              </Text>
              <Image
                imageUrl={item.icon || item.pic}
                frame={iconSize}
                widgetAccentedRenderingMode={settings.renderingMode}
                resizable
              />
              <Spacer />
            </HStack>
          </Link>
          {i === 0 ? (
            // 时钟仅作时间展示，不可点击：AppIntent 会启动 App，且 SwiftUI 不允许 Link 套 Link。
            <HStack spacing={2}>
              <Image
                systemName='clock.arrow.circlepath'
                font={settings.fontSize * 0.7}
                foregroundStyle={settings.timeColor}
              />
              <Text
                font={settings.fontSize * 0.7}
                foregroundStyle={settings.timeColor}
              >
                {`${now.getHours()}`.padStart(2, '0')}:
                {`${now.getMinutes()}`.padStart(2, '0')}
              </Text>
            </HStack>
          ) : null}
        </HStack>
      ))}
      <HStack alignment='bottom'>
        <VStack spacing={0}>
          {list.slice(count - logoLines, count).map((item, i) => (
            <Link key={item.itemid} buttonStyle='plain' url={getItemLink(item)}>
              <HStack
                key={item.itemid}
                frame={{ height: itemHeight }}
                alignment='center'
              >
                <Text
                  font={settings.fontSize}
                  fontWeight='bold'
                  foregroundStyle={item.itemid <= 3 ? '#fe4f67' : '#f5c94c'}
                >
                  {item.itemid}
                </Text>
                <Text font={settings.fontSize} foregroundStyle={settings.color}>
                  {item.title}
                </Text>
                <Image
                  imageUrl={item.icon || item.pic}
                  frame={iconSize}
                  widgetAccentedRenderingMode={settings.renderingMode}
                  resizable
                />
                <Spacer />
              </HStack>
            </Link>
          ))}
        </VStack>
        <Link url={hotSearchLink}>
          <Image
            imageUrl='https://www.sinaimg.cn/blog/developer/wiki/LOGO_64x64.png'
            frame={{ width: settings.logoSize, height: settings.logoSize }}
            widgetAccentedRenderingMode={settings.renderingMode}
            resizable
          />
        </Link>
      </HStack>
    </VStack>
  )
}

;(async () => {
  const url = 'https://weibointl.api.weibo.cn/portal.php?ct=feed&a=search_hot'
  const { data } = await fetch(url).then((resp) => resp.json())
  Widget.present(<WidgetView list={Array.isArray(data) ? data : []} />)
})()
