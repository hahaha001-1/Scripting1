import { Color, Storage, useReducer } from 'scripting'
import { SOURCES } from '../apis/sources'

export interface Settings {
  /** 订阅源排序（id 数组）。为空时回落到 SOURCES 默认顺序。 */
  sourceOrder: string[]
  fontSize: number
  color: { light: Color; dark: Color }
}

function initState(): Settings {
  const stored = Storage.get<Settings>('settings')
  return {
    sourceOrder: SOURCES.map((s) => s.id),
    fontSize: 16,
    color: { light: '#1a1a1a', dark: '#ffffff' },
    ...stored,
  }
}

function reducer(state: Settings, action: Partial<Settings>) {
  return { ...state, ...action }
}

export function useSettings() {
  const [state, dispatch] = useReducer(reducer, initState())
  function setSettings(data: Partial<Settings>) {
    const newState = { ...state, ...data }
    Storage.set('settings', newState)
    dispatch(newState)
  }
  return [state, setSettings] as const
}
