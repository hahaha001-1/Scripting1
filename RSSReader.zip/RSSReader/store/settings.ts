import { Color, Storage, useReducer, WidgetAccentedRenderingMode } from 'scripting'

export interface Settings {
  /** 桌面小组件显示的数据源 id */
  widgetSourceId: string
  fontSize: number
  gap: number
  color: { light: Color; dark: Color }
  /** 用于小组件标题/序号的强调色 */
  timeColor: { light: Color; dark: Color }
  background: { light: Color; dark: Color }
  renderingMode: WidgetAccentedRenderingMode
}

function initState(): Settings {
  const stored = Storage.get<Settings>('settings')
  return {
    widgetSourceId: 'hackernews',
    fontSize: 14,
    gap: 8,
    color: { light: '#333333', dark: '#ffffff' },
    timeColor: { light: '#ff6b35', dark: '#ff9f1c' },
    background: { light: '#ffffff', dark: '#242426' },
    renderingMode: 'accentedDesaturated',
    ...stored,
  }
}

function reducer(state: Settings, action: Partial<Settings>) {
  return { ...state, ...action }
}

export function useSettings() {
  const [state, dispatch] = useReducer(reducer, initState())
  function setSettings(data: Partial<Settings>) {
    const newState = { ...state, ...data }
    Storage.set('settings', newState)
    dispatch(newState)
  }
  return [state, setSettings] as const
}
