import {
  Navigation,
  Script,
  TabView,
  Tab,
  useObservable,
  NavigationStack,
  useColorScheme,
} from 'scripting'
import { orderedSources } from './apis/sources'
import ArticleList from './pages/ArticleList'
import { useSettings } from './store/settings'

function App() {
  const tabSelection = useObservable<number>(0)
  const [settings] = useSettings()
  const colorScheme = useColorScheme()
  const sources = orderedSources(settings.sourceOrder)

  return (
    <TabView tint='systemOrange' selection={tabSelection}>
      {sources.map((s, i) => (
        <Tab key={s.id} title={s.name} systemImage={s.icon} value={i}>
          <NavigationStack>
            <ArticleList sourceId={s.id} />
          </NavigationStack>
        </Tab>
      ))}
    </TabView>
  )
}

async function main() {
  await Navigation.present(<App />)
  Script.exit()
}

main().catch((err) => {
  console.error(err)
  Script.exit()
})
