import {
  Navigation,
  Script,
  TabView,
  Label,
  useState,
  NavigationStack,
  List,
  Text,
  NavigationLink,
  Image,
  HStack,
  VStack,
  Spacer,
} from 'scripting'
import { SOURCES, GROUP_NAMES } from './apis/sources'
import ArticleList from './pages/ArticleList'
import Settings from './pages/Settings'

function SourceTab({
  group,
  tag,
  tabItem,
}: {
  group: 1 | 2
  tag: number
  tabItem: any
}) {
  const sources = SOURCES.filter((s) => s.group === group)
  return (
    <NavigationStack>
      <List
        navigationTitle={GROUP_NAMES[group]}
        toolbar={{
          topBarTrailing: [
            <NavigationLink destination={<Settings />} key='settings'>
              <Image systemName='gearshape.fill' />
            </NavigationLink>,
          ],
        }}
      >
        {sources.map((s) => (
          <NavigationLink key={s.id} destination={<ArticleList sourceId={s.id} />}>
            <HStack alignment='center'>
              <VStack alignment='leading' spacing={2}>
                <Text fontSize={16} fontWeight='medium'>
                  {s.name}
                </Text>
                <Text fontSize={12} foregroundStyle='secondary'>
                  {s.homepage.replace(/^https?:\/\//, '')}
                </Text>
              </VStack>
              <Spacer />
            </HStack>
          </NavigationLink>
        ))}
      </List>
    </NavigationStack>
  )
}

function Root() {
  const [tabIndex, setTabIndex] = useState(0)
  return (
    <TabView tabIndex={tabIndex} onTabIndexChanged={setTabIndex}>
      <SourceTab
        tag={0}
        group={1}
        tabItem={<Label title='技术' systemImage='globe' />}
      />
      <SourceTab
        tag={1}
        group={2}
        tabItem={<Label title='AI' systemImage='cpu' />}
      />
    </TabView>
  )
}

const run = async () => {
  await Navigation.present({
    element: <Root />,
  })
  Script.exit()
}

run()
