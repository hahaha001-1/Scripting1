import {
  List,
  Section,
  Text,
  NavigationLink,
  Image,
  HStack,
  Spacer,
  useCallback,
  useEffect,
  useState,
  useColorScheme,
} from 'scripting'
import { getSource } from '../apis/sources'
import { Article } from '../apis/parse'
import ArticleRow from '../components/ArticleRow'
import ArticleView from './ArticleView'
import Settings from './Settings'
import { useSettings } from '../store/settings'

export default function ArticleList({ sourceId }: { sourceId: string }) {
  const source = getSource(sourceId)
  const [articles, setArticles] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)
  const [settings] = useSettings()
  const colorScheme = useColorScheme()
  const color = settings.color[colorScheme]

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const data = await source.fetchArticles(source.url)
      setArticles(data)
    } catch (e) {
      setArticles([])
    }
    setLoading(false)
  }, [sourceId])

  useEffect(() => {
    load()
  }, [load])

  return (
    <List
      navigationTitle={source.name}
      navigationBarTitleDisplayMode='large'
      refreshable={load}
      toolbar={{
        topBarTrailing: [
          <NavigationLink destination={<Settings />} key='settings'>
            <Image systemName='gearshape.fill' />
          </NavigationLink>,
        ],
      }}
    >
      {articles.map((it, i) => (
        <NavigationLink
          key={it.url}
          destination={<ArticleView url={it.url} title={it.title} />}
        >
          <ArticleRow item={it} index={i} fontSize={settings.fontSize} color={color} />
        </NavigationLink>
      ))}

      {loading && articles.length === 0 ? (
        <Section>
          <Text>加载中…</Text>
        </Section>
      ) : null}

      {!loading && articles.length === 0 ? (
        <Section>
          <Text>暂无内容（该源可能需要网络访问，或地址已变更）</Text>
        </Section>
      ) : null}
    </List>
  )
}
