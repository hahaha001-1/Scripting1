import {
  NavigationStack,
  List,
  Section,
  Text,
  NavigationLink,
  useCallback,
  useEffect,
  useState,
} from 'scripting'
import { getSource } from '../apis/sources'
import { Article } from '../apis/parse'
import ArticleRow from '../components/ArticleRow'
import ArticleView from './ArticleView'

export default function ArticleList({ sourceId }: { sourceId: string }) {
  const source = getSource(sourceId)
  const [articles, setArticles] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const data = await source.fetchArticles()
      setArticles(data)
    } catch (e) {
      setArticles([])
    }
    setLoading(false)
  }, [sourceId])

  useEffect(() => {
    load()
  }, [load])

  return (
    <NavigationStack>
      <List navigationTitle={source.name} refreshable={load}>
        {articles.map((it, i) => (
          <NavigationLink
            key={it.url}
            destination={<ArticleView url={it.url} title={it.title} />}
          >
            <ArticleRow item={it} index={i} fontSize={16} color='#1a1a1a' />
          </NavigationLink>
        ))}

        {loading && articles.length === 0 ? (
          <Section>
            <Text>加载中…</Text>
          </Section>
        ) : null}

        {!loading && articles.length === 0 ? (
          <Section>
            <Text>暂无内容（该源可能需要网络访问，或接口已变更）</Text>
          </Section>
        ) : null}
      </List>
    </NavigationStack>
  )
}
