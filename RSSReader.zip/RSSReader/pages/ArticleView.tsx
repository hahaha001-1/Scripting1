import { WebViewController, WebView, useMemo, useEffect } from 'scripting'

export default function ArticleView({ url, title }: { url: string; title?: string }) {
  const controller = useMemo(() => new WebViewController(), [])

  useEffect(() => {
    ;(async () => {
      await controller.loadURL(url)
      controller.canGoBack()
    })()
  }, [])

  return (
    <WebView
      navigationBarTitleDisplayMode='inline'
      frame={{ maxWidth: 'infinity', maxHeight: 'infinity' }}
      controller={controller}
    />
  )
}
