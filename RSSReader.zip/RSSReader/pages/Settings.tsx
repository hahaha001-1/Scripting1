import {
  List,
  Section,
  Text,
  ColorPicker,
  Stepper,
  HStack,
  Spacer,
  Button,
  useMemo,
  useCallback,
  useColorScheme,
  type Color,
} from 'scripting'
import { useSettings } from '../store/settings'
import { SOURCES, presetSources } from '../apis/sources'

export default function Settings() {
  const [settings, setSettings] = useSettings()
  const colorScheme = useColorScheme()
  const color = useMemo(() => settings.color[colorScheme], [settings.color, colorScheme])

  // 当前启用的源（id 数组）；为空数组表示全部删掉了
  const active: string[] = settings.sourceOrder ?? []
  const nameOf = (id: string) => SOURCES.find((s) => s.id === id)?.name ?? id
  const presets = useMemo(() => presetSources(active), [active])

  const move = useCallback(
    (from: number, to: number) => {
      if (to < 0 || to >= active.length) return
      const arr = [...active]
      const [item] = arr.splice(from, 1)
      arr.splice(to, 0, item)
      setSettings({ sourceOrder: arr })
    },
    [active],
  )

  const remove = useCallback(
    (id: string) => {
      setSettings({ sourceOrder: active.filter((x) => x !== id) })
    },
    [active],
  )

  const add = useCallback(
    (id: string) => {
      setSettings({ sourceOrder: [...active, id] })
    },
    [active],
  )

  const onDecrement = useCallback(() => {
    setSettings({ fontSize: Math.max(10, settings.fontSize - 1) })
  }, [settings.fontSize])

  const onIncrement = useCallback(() => {
    setSettings({ fontSize: Math.min(26, settings.fontSize + 1) })
  }, [settings.fontSize])

  const onColorChanged = useCallback(
    (value: Color) => {
      setSettings({ color: { ...settings.color, [colorScheme]: value } })
    },
    [settings.color, colorScheme],
  )

  return (
    <List navigationTitle='设置' navigationBarTitleDisplayMode='inline'>
      <Section header={<Text>我的订阅源（{active.length}）· 上移 / 下移 / 删除</Text>}>
        {active.length === 0 ? (
          <Text fontSize={13} foregroundStyle='secondary'>
            已无启用源，从下方「添加预设源」恢复。
          </Text>
        ) : null}
        {active.map((id, i) => (
          <HStack key={id}>
            <Text>{i + 1}. {nameOf(id)}</Text>
            <Spacer />
            <Button title='↑' action={() => move(i, i - 1)} disabled={i === 0} />
            <Button title='↓' action={() => move(i, i + 1)} disabled={i === active.length - 1} />
            <Button title='删除' action={() => remove(id)} />
          </HStack>
        ))}
      </Section>

      <Section header={<Text>添加预设源（共 {presets.length}）</Text>}>
        {presets.length === 0 ? (
          <Text fontSize={13} foregroundStyle='secondary'>
            全部预设源都已添加。
          </Text>
        ) : null}
        {presets.map((s) => (
          <HStack key={s.id}>
            <Text>{s.name}</Text>
            <Spacer />
            <Button title='添加' action={() => add(s.id)} />
          </HStack>
        ))}
      </Section>

      <Section header={<Text>阅读外观</Text>}>
        <HStack>
          <Stepper title='字体大小' onDecrement={onDecrement} onIncrement={onIncrement} />
          <Text>{settings.fontSize}</Text>
        </HStack>
        <ColorPicker title='正文颜色' value={color} onChanged={onColorChanged} />
      </Section>

      <Section header={<Text>关于</Text>}>
        <Text fontSize={12} foregroundStyle='secondary'>
          多源 RSS 阅读器 · 每源一个页签。源地址集中在 apis/sources.ts，可随时增删改。
        </Text>
      </Section>
    </List>
  )
}
