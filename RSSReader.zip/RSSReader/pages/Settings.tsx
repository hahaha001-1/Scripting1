import {
  List,
  Section,
  Text,
  Picker,
  ColorPicker,
  Stepper,
  HStack,
  useMemo,
  useCallback,
  useColorScheme,
  type Color,
  type WidgetAccentedRenderingMode,
} from 'scripting'
import { useSettings } from '../store/settings'
import { SOURCES, GROUP_NAMES } from '../apis/sources'

export default function Settings() {
  const [settings, setSettings] = useSettings()
  const colorScheme = useColorScheme()
  const color = useMemo(() => settings.color[colorScheme], [settings.color, colorScheme])
  const background = useMemo(
    () => settings.background[colorScheme],
    [settings.background, colorScheme],
  )

  const onDecrement = useCallback(() => {
    setSettings({ fontSize: Math.max(10, settings.fontSize - 1) })
  }, [settings.fontSize])

  const onIncrement = useCallback(() => {
    setSettings({ fontSize: Math.min(22, settings.fontSize + 1) })
  }, [settings.fontSize])

  const onColorChanged = useCallback(
    (value: Color) => {
      setSettings({ color: { ...settings.color, [colorScheme]: value } })
    },
    [settings.color, colorScheme],
  )

  const onBackgroundChanged = useCallback(
    (value: Color) => {
      setSettings({ background: { ...settings.background, [colorScheme]: value } })
    },
    [settings.background, colorScheme],
  )

  return (
    <List navigationTitle='设置' navigationBarTitleDisplayMode='inline'>
      <Section header={<Text>小组件数据源</Text>}>
        <Picker
          title='数据源'
          pickerStyle='navigationLink'
          value={settings.widgetSourceId}
          onChanged={(v) => setSettings({ widgetSourceId: String(v) })}
        >
          {SOURCES.map((s) => (
            <Text key={s.id} tag={s.id}>
              {GROUP_NAMES[s.group]} · {s.name}
            </Text>
          ))}
        </Picker>
        <Text fontSize={12} foregroundStyle='secondary'>
          小组件仅能展示单个数据源；添加两个小组件并分别选择「技术资讯 / AI 前沿」下的源即可对照浏览。
        </Text>
      </Section>

      <Section header={<Text>外观</Text>}>
        <HStack>
          <Stepper title='字体大小' onDecrement={onDecrement} onIncrement={onIncrement} />
          <Text>{settings.fontSize}</Text>
        </HStack>
        <ColorPicker title='文字颜色' value={color} onChanged={onColorChanged} />
        <ColorPicker title='背景颜色' value={background} onChanged={onBackgroundChanged} />
        <Picker
          title='图标染色模式'
          pickerStyle='navigationLink'
          value={settings.renderingMode}
          onChanged={(v) => setSettings({ renderingMode: v as WidgetAccentedRenderingMode })}
        >
          <Text tag='accented'>accented</Text>
          <Text tag='desaturated'>desaturated</Text>
          <Text tag='accentedDesaturated'>accentedDesaturated</Text>
          <Text tag='fullColor'>fullColor</Text>
        </Picker>
      </Section>
    </List>
  )
}
