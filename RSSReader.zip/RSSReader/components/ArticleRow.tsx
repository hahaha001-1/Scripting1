import { HStack, Text, VStack } from 'scripting'
import { Article } from '../apis/parse'

export default function ArticleRow({
  item,
  index,
  fontSize,
  color,
}: {
  item: Article
  index: number
  fontSize: number
  color: string
}) {
  return (
    <HStack alignment='top' spacing={8}>
      <Text
        font={fontSize}
        fontWeight='bold'
        foregroundStyle={index < 3 ? '#fe4f67' : '#f5c94c'}
      >
        {index + 1}
      </Text>
      <VStack alignment='leading' spacing={2}>
        <Text font={fontSize} fontWeight='medium' foregroundStyle={color}>
          {item.title}
        </Text>
        {item.summary ? (
          <Text font={fontSize * 0.85} foregroundStyle='secondary' numberOfLines={2}>
            {item.summary}
          </Text>
        ) : null}
      </VStack>
    </HStack>
  )
}
