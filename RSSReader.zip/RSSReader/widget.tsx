import {
  HStack,
  VStack,
  Text,
  Link,
  Spacer,
  Widget,
  Storage,
} from 'scripting'
import { useSettings } from './store/settings'
import { getSource } from './apis/sources'
import { Article } from './apis/parse'

function WidgetView({ list }: { list: Article[] }) {
  const [settings] = useSettings()
  const { height } = Widget.displaySize
  const paddingY = 12
  const source = getSource(settings.widgetSourceId)

  const standardItemHeight = settings.fontSize + settings.gap
  const count = Math.max(1, Math.floor((height - paddingY * 2 + settings.gap) / standardItemHeight))
  const itemHeight = standardItemHeight + (height - paddingY * 2 - standardItemHeight * count) / count

  return (
    <VStack
      padding={{ horizontal: 14, vertical: paddingY }}
      frame={Widget.displaySize}
      spacing={0}
      widgetBackground={settings.background}
    >
      <Link url={source.homepage}>
        <HStack>
          <Text fontSize={settings.fontSize + 2} fontWeight='bold' foregroundStyle={settings.timeColor}>
            {source.name}
          </Text>
          <Spacer />
          <Text fontSize={settings.fontSize * 0.75} foregroundStyle={settings.timeColor}>
            RSS
          </Text>
        </HStack>
      </Link>

      {list.slice(0, count).map((item, i) => (
        <Link key={item.url} buttonStyle='plain' url={item.url}>
          <HStack frame={{ height: itemHeight }} alignment='center'>
            <Text
              font={settings.fontSize}
              fontWeight='bold'
              foregroundStyle={i < 3 ? '#fe4f67' : '#f5c94c'}
            >
              {i + 1}
            </Text>
            <Text font={settings.fontSize} foregroundStyle={settings.color} numberOfLines={1}>
              {item.title}
            </Text>
            <Spacer />
          </HStack>
        </Link>
      ))}

      {list.length === 0 ? (
        <Text fontSize={settings.fontSize} foregroundStyle={settings.timeColor}>
          加载中或源不可用
        </Text>
      ) : null}
    </VStack>
  )
}

;(async () => {
  const stored = Storage.get<{ widgetSourceId?: string }>('settings')
  const source = getSource(stored?.widgetSourceId || 'hackernews')
  let list: Article[] = []
  try {
    list = await source.fetchArticles()
  } catch (e) {
    list = []
  }
  Widget.present(<WidgetView list={Array.isArray(list) ? list : []} />)
})()
