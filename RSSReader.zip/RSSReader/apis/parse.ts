import { fetch } from 'scripting'

export interface Article {
  title: string
  url: string
  summary?: string
  date?: string
  source: string
}

// ---------------- text helpers ----------------
const ENTITIES: Record<string, string> = {
  '&amp;': '&',
  '&lt;': '<',
  '&gt;': '>',
  '&quot;': '"',
  '&apos;': "'",
  '&nbsp;': ' ',
}

export function decodeEntities(s: string): string {
  if (!s) return ''
  let out = s.replace(/&(?:amp|lt|gt|quot|apos|nbsp);/gi, (m) => ENTITIES[m.toLowerCase()] ?? m)
  out = out.replace(/&#(\d+);/g, (_, n) => String.fromCharCode(parseInt(n, 10)))
  out = out.replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCharCode(parseInt(n, 16)))
  return out
}

export function stripHtml(s: string): string {
  if (!s) return ''
  let v = s
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<script[\s\S]*?<\/script>/gi, '')
  // 先解码实体（如 &lt;div&gt; → <div>），再剔除标签，否则转义后的标签会残留
  v = decodeEntities(v)
  v = v.replace(/<[^>]+>/g, ' ')
  v = v.replace(/[<>]/g, '')
  return v.replace(/\s+/g, ' ').trim()
}

export function cleanText(s?: string, max = 160): string {
  return stripHtml(s ?? '').slice(0, max)
}

async function fetchText(url: string): Promise<string> {
  try {
    const resp = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; RSSReader/1.0)' } })
    return await resp.text()
  } catch (e) {
    // 个别环境对 fetch 的第二个参数（options）支持不一致，退回单参调用
    const resp = await fetch(url)
    return await resp.text()
  }
}

// ---------------- RSS / Atom ----------------
export function parseFeed(xml: string, sourceId: string): Article[] {
  const isAtom = /<feed[\s>]/.test(xml)
  const blocks = isAtom
    ? xml.match(/<entry[\s\S]*?<\/entry>/g) || []
    : xml.match(/<item[\s\S]*?<\/item>/g) || []
  const items: Article[] = []
  for (const b of blocks) {
    const title = pick(b, 'title')
    const link = isAtom ? atomLink(b) : rssLink(b)
    const summary =
      pick(b, isAtom ? 'summary' : 'description') ||
      pick(b, 'content:encoded') ||
      pick(b, 'content')
    const date = pick(b, 'pubDate') || pick(b, 'published') || pick(b, 'updated') || pick(b, 'dc:date')
    if (!title || !link) continue
    items.push({
      title: stripHtml(title).slice(0, 200),
      url: decodeEntities(link.trim()).replace(/^http:\/\//, 'https://'),
      summary: cleanText(summary),
      date: date ? stripHtml(date).trim() : undefined,
      source: sourceId,
    })
  }
  return items
}

// RSS <link> 可能两种写法：
//   <link>https://x</link>            （文本）
//   <link href="https://x"/>          （自闭合 + href 属性，OpenAI / 36氪 / BBC 等用这种）
// 旧的解析只处理了文本写法，导致大量 RSS 项因拿不到链接被丢弃。
function rssLink(block: string): string {
  const text = pick(block, 'link')
  if (text) return text
  const href = block.match(/<link[^>]*href="([^"]+)"/i)
  return href ? href[1] : ''
}

function pick(block: string, tag: string): string {
  const re = new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, 'i')
  const m = block.match(re)
  if (!m) return ''
  let v = m[1]
  const cd = v.match(/<!\[CDATA\[([\s\S]*?)\]\]>/)
  if (cd) v = cd[1]
  return v.trim()
}

function atomLink(block: string): string {
  const alt = block.match(/<link[^>]*rel="alternate"[^>]*href="([^"]+)"/i)
  if (alt) return alt[1]
  const any = block.match(/<link[^>]*href="([^"]+)"/i)
  return any ? any[1] : ''
}

export async function fetchFeed(url: string, sourceId: string): Promise<Article[]> {
  const xml = await fetchText(url)
  return parseFeed(xml, sourceId)
}
