import { fetch } from 'scripting'

export interface Article {
  title: string
  url: string
  summary?: string
  date?: string
  source: string
}

// ---------------- text helpers ----------------
const ENTITIES: Record<string, string> = {
  '&amp;': '&',
  '&lt;': '<',
  '&gt;': '>',
  '&quot;': '"',
  '&apos;': "'",
  '&nbsp;': ' ',
}

export function decodeEntities(s: string): string {
  if (!s) return ''
  let out = s.replace(/&(?:amp|lt|gt|quot|apos|nbsp);/gi, (m) => ENTITIES[m.toLowerCase()] ?? m)
  out = out.replace(/&#(\d+);/g, (_, n) => String.fromCharCode(parseInt(n, 10)))
  out = out.replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCharCode(parseInt(n, 16)))
  return out
}

export function stripHtml(s: string): string {
  if (!s) return ''
  let v = s
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<script[\s\S]*?<\/script>/gi, '')
  // 先解码实体（如 &lt;div&gt; → <div>），再剔除标签，否则转义后的标签会残留
  v = decodeEntities(v)
  v = v.replace(/<[^>]+>/g, ' ')
  v = v.replace(/[<>]/g, '')
  return v.replace(/\s+/g, ' ').trim()
}

export function cleanText(s?: string, max = 160): string {
  return stripHtml(s ?? '').slice(0, max)
}

async function fetchText(url: string): Promise<string> {
  const resp = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; RSSReader/1.0)' } })
  return await resp.text()
}

// ---------------- RSS / Atom ----------------
export function parseFeed(xml: string, sourceId: string): Article[] {
  const isAtom = /<feed[\s>]/.test(xml)
  const blocks = isAtom
    ? xml.match(/<entry[\s\S]*?<\/entry>/g) || []
    : xml.match(/<item[\s\S]*?<\/item>/g) || []
  const items: Article[] = []
  for (const b of blocks) {
    const title = pick(b, 'title')
    const link = isAtom ? atomLink(b) : pick(b, 'link')
    const summary =
      pick(b, isAtom ? 'summary' : 'description') ||
      pick(b, 'content:encoded') ||
      pick(b, 'content')
    const date = pick(b, 'pubDate') || pick(b, 'published') || pick(b, 'updated') || pick(b, 'dc:date')
    if (!title || !link) continue
    items.push({
      title: stripHtml(title).slice(0, 200),
      url: decodeEntities(link.trim()).replace(/^http:\/\//, 'https://'),
      summary: cleanText(summary),
      date: date ? stripHtml(date).trim() : undefined,
      source: sourceId,
    })
  }
  return items
}

function pick(block: string, tag: string): string {
  const re = new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, 'i')
  const m = block.match(re)
  if (!m) return ''
  let v = m[1]
  const cd = v.match(/<!\[CDATA\[([\s\S]*?)\]\]>/)
  if (cd) v = cd[1]
  return v.trim()
}

function atomLink(block: string): string {
  const alt = block.match(/<link[^>]*rel="alternate"[^>]*href="([^"]+)"/i)
  if (alt) return alt[1]
  const any = block.match(/<link[^>]*href="([^"]+)"/i)
  return any ? any[1] : ''
}

export async function fetchFeed(url: string, sourceId: string): Promise<Article[]> {
  const xml = await fetchText(url)
  return parseFeed(xml, sourceId)
}

// ---------------- JSON APIs ----------------
export async function fetchHN(): Promise<Article[]> {
  const url = 'https://hn.algolia.com/api/v1/search?tags=front_page&hitsPerPage=20'
  const resp = await fetch(url)
  const json = await resp.json()
  const hits: any[] = json.hits || []
  return hits.map((h) => ({
    title: h.title || h.story_title || '(无标题)',
    url: h.url || `https://news.ycombinator.com/item?id=${h.objectID}`,
    summary: h.points != null ? `▲ ${h.points} · 💬 ${h.num_comments ?? 0}` : undefined,
    date: h.created_at,
    source: 'hackernews',
  }))
}

export async function fetchV2EX(): Promise<Article[]> {
  const url = 'https://www.v2ex.com/api/topics/hot.json'
  const resp = await fetch(url)
  const arr: any[] = await resp.json()
  return (arr || []).map((t) => ({
    title: t.title,
    url: `https://www.v2ex.com/t/${t.id}`,
    summary: t.node?.title ? `节点：${t.node.title}` : undefined,
    date: t.last_modified ? new Date(t.last_modified * 1000).toISOString() : undefined,
    source: 'v2ex',
  }))
}

// ---------------- HTML scraping ----------------
export async function fetchGitHub(): Promise<Article[]> {
  const html = await fetchText('https://github.com/trending')
  const arts: Article[] = []
  const re = /<article class="Box-row">([\s\S]*?)<\/article>/g
  let m: RegExpExecArray | null
  while ((m = re.exec(html))) {
    const b = m[1]
    const repo = b.match(/<h2 class="h3 lh-condensed">\s*<a[^>]*href="([^"]+)"/i)
    if (!repo) continue
    const path = repo[1].trim()
    const name = decodeEntities(path.replace(/^\//, '')).replace('/', ' / ')
    const desc = b.match(/<p class="col-9 color-fg-muted[^"]*">([\s\S]*?)<\/p>/i)
    arts.push({
      title: name,
      url: 'https://github.com' + path,
      summary: desc ? cleanText(desc[1]) : undefined,
      source: 'github',
    })
  }
  return arts
}

export async function fetchAnthropic(): Promise<Article[]> {
  const html = await fetchText('https://www.anthropic.com/news')
  const arts: Article[] = []
  const seen = new Set<string>()
  const re = /<a\s+[^>]*href="(\/news\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/g
  let m: RegExpExecArray | null
  while ((m = re.exec(html))) {
    const href = m[1]
    if (seen.has(href)) continue
    const inner = m[2]
    const h = inner.match(/<h[1-6][^>]*>([\s\S]*?)<\/h[1-6]>/i)
    const title = stripHtml(h ? h[1] : inner)
    if (!title) continue
    seen.add(href)
    arts.push({
      title,
      url: 'https://www.anthropic.com' + href,
      source: 'anthropic',
    })
  }
  return arts
}

export async function fetchSF(): Promise<Article[]> {
  const html = await fetchText('https://segmentfault.com/')
  const arts: Article[] = []
  const seen = new Set<string>()
  const re = /<a\s+href="(\/a\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/g
  let m: RegExpExecArray | null
  while ((m = re.exec(html))) {
    const href = m[1]
    if (seen.has(href)) continue
    const inner = m[2]
    const mb = inner.match(/<div class="media-body">([\s\S]*?)<\/div>/i)
    let title = stripHtml(mb ? mb[1] : inner).replace(/^\d+\s+/, '')
    if (!title) continue
    seen.add(href)
    arts.push({
      title: title.slice(0, 80),
      url: 'https://segmentfault.com' + href,
      source: 'sf',
    })
  }
  return arts
}
