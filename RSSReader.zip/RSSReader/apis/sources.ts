import { fetchFeed, Article } from './parse'

export interface Source {
  id: string
  name: string
  /** 订阅地址（https 直链，RSS 或 Atom） */
  url: string
  /** Tab 图标（SF Symbol 名称） */
  icon: string
  fetchArticles: (url: string) => Promise<Article[]>
}

// 默认顺序即下方数组顺序；自定义排序存于 settings.sourceOrder。
export const SOURCES: Source[] = [
  {
    id: 'ruanyifeng',
    name: '阮一峰的网络日志',
    url: 'https://www.ruanyifeng.com/blog/atom.xml',
    icon: 'book.fill',
    fetchArticles: (url) => fetchFeed(url, 'ruanyifeng'),
  },
  {
    id: 'sspai',
    name: '少数派',
    url: 'https://sspai.com/feed',
    icon: 'pencil',
    fetchArticles: (url) => fetchFeed(url, 'sspai'),
  },
  {
    id: 'v2ex-tech',
    name: 'V2EX 技术',
    url: 'https://www.v2ex.com/feed/tab/tech.xml',
    icon: 'bubble.right.fill',
    fetchArticles: (url) => fetchFeed(url, 'v2ex-tech'),
  },
  {
    id: 'infoq',
    name: 'InfoQ 中文',
    url: 'https://www.infoq.cn/feed',
    icon: 'newspaper.fill',
    fetchArticles: (url) => fetchFeed(url, 'infoq'),
  },
  {
    id: 'jiqizhixin',
    name: '机器之心',
    url: 'https://www.jiqizhixin.com/rss',
    icon: 'cpu.fill',
    fetchArticles: (url) => fetchFeed(url, 'jiqizhixin'),
  },
  {
    id: 'openai',
    name: 'OpenAI Blog',
    url: 'https://openai.com/news/rss.xml',
    icon: 'brain.fill',
    fetchArticles: (url) => fetchFeed(url, 'openai'),
  },
  {
    id: 'anthropic',
    name: 'Anthropic News',
    url: 'https://www.anthropic.com/news/rss.xml',
    icon: 'sparkles',
    fetchArticles: (url) => fetchFeed(url, 'anthropic'),
  },
  {
    id: 'huggingface',
    name: 'Hugging Face Blog',
    url: 'https://huggingface.co/blog/feed.xml',
    icon: 'cube.fill',
    fetchArticles: (url) => fetchFeed(url, 'huggingface'),
  },
  {
    id: 'github-blog',
    name: 'GitHub Blog',
    url: 'https://github.blog/feed/',
    icon: 'curlybraces',
    fetchArticles: (url) => fetchFeed(url, 'github-blog'),
  },
  {
    id: 'arxiv-ai',
    name: 'arXiv AI',
    url: 'https://rss.arxiv.org/rss/cs.AI',
    icon: 'lightbulb.fill',
    fetchArticles: (url) => fetchFeed(url, 'arxiv-ai'),
  },
  {
    id: '36kr',
    name: '36氪',
    url: 'https://36kr.com/feed',
    icon: 'bolt.fill',
    fetchArticles: (url) => fetchFeed(url, '36kr'),
  },
  {
    id: 'ifanr',
    name: '爱范儿',
    url: 'https://www.ifanr.com/feed',
    icon: 'app.fill',
    fetchArticles: (url) => fetchFeed(url, 'ifanr'),
  },
  {
    id: 'bbc-zhongwen',
    name: 'BBC 中文',
    url: 'https://feeds.bbci.co.uk/zhongwen/simp/rss.xml',
    icon: 'globe',
    fetchArticles: (url) => fetchFeed(url, 'bbc-zhongwen'),
  },
  {
    id: 'zaobao',
    name: '联合早报',
    url: 'https://www.zaobao.com.sg/rss',
    icon: 'doc.text.fill',
    fetchArticles: (url) => fetchFeed(url, 'zaobao'),
  },
  {
    id: 'macrumors',
    name: 'MacRumors',
    url: 'https://www.macrumors.com/macrumors.xml',
    icon: 'applelogo',
    fetchArticles: (url) => fetchFeed(url, 'macrumors'),
  },
]

export function getSource(id: string): Source {
  return SOURCES.find((s) => s.id === id) || SOURCES[0]
}

/**
 * 按自定义顺序返回「当前启用的」源列表（settings.sourceOrder 中的 id）。
 * 只返回 order 里存在的源，不在 order 中的预设源视为已删除，不会自动补回
 * （删除要真的生效；要恢复就从设置的「添加预设源」里加回）。
 */
export function orderedSources(order: string[]): Source[] {
  const map = new Map(SOURCES.map((s) => [s.id, s]))
  const out: Source[] = []
  for (const id of order) {
    const s = map.get(id)
    if (s) out.push(s)
  }
  return out
}

/** 所有预设源（含当前未启用的），供「添加预设源」使用 */
export function presetSources(activeIds: string[]): Source[] {
  const set = new Set(activeIds)
  return SOURCES.filter((s) => !set.has(s.id))
}
