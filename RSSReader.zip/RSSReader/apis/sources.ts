import {
  fetchHN,
  fetchV2EX,
  fetchGitHub,
  fetchAnthropic,
  fetchSF,
  fetchFeed,
  Article,
} from './parse'

export interface Source {
  id: string
  name: string
  group: 1 | 2
  homepage: string
  fetchArticles: () => Promise<Article[]>
}

// 组 1：技术资讯；组 2：AI 前沿（对应需求里的两个页签）
export const SOURCES: Source[] = [
  // —— 页签 1：技术资讯 ——
  {
    id: 'hackernews',
    name: 'Hacker News',
    group: 1,
    homepage: 'https://news.ycombinator.com/',
    fetchArticles: fetchHN,
  },
  {
    id: 'github',
    name: 'GitHub Trending',
    group: 1,
    homepage: 'https://github.com/trending',
    fetchArticles: fetchGitHub,
  },
  {
    id: 'infoq',
    name: 'InfoQ',
    group: 1,
    homepage: 'https://www.infoq.cn/',
    fetchArticles: () => fetchFeed('https://www.infoq.cn/feed', 'infoq'),
  },
  {
    id: 'juejin',
    name: '掘金',
    group: 1,
    homepage: 'https://juejin.cn/',
    fetchArticles: () => fetchFeed('https://juejin.cn/rss', 'juejin'),
  },
  {
    id: 'sf',
    name: '思否',
    group: 1,
    homepage: 'https://segmentfault.com/',
    fetchArticles: fetchSF,
  },
  {
    id: 'v2ex',
    name: 'V2EX',
    group: 1,
    homepage: 'https://www.v2ex.com/',
    fetchArticles: fetchV2EX,
  },
  // —— 页签 2：AI 前沿 ——
  {
    id: 'openai',
    name: 'OpenAI Blog',
    group: 2,
    homepage: 'https://openai.com/blog',
    fetchArticles: () => fetchFeed('https://openai.com/blog/rss.xml', 'openai'),
  },
  {
    id: 'anthropic',
    name: 'Anthropic News',
    group: 2,
    homepage: 'https://www.anthropic.com/news',
    fetchArticles: fetchAnthropic,
  },
  {
    id: 'googleai',
    name: 'Google AI Blog',
    group: 2,
    homepage: 'https://blog.google/technology/ai/',
    fetchArticles: () => fetchFeed('https://blog.google/technology/ai/rss/', 'googleai'),
  },
  {
    id: 'huggingface',
    name: 'HuggingFace Blog',
    group: 2,
    homepage: 'https://huggingface.co/blog',
    fetchArticles: () => fetchFeed('https://huggingface.co/blog/feed.xml', 'huggingface'),
  },
  {
    id: 'arxiv',
    name: 'arXiv AI',
    group: 2,
    homepage: 'https://arxiv.org/list/cs.AI/recent',
    fetchArticles: () =>
      fetchFeed(
        'http://export.arxiv.org/api/query?search_query=cat:cs.AI&sortBy=submittedDate&sortOrder=descending&max_results=20',
        'arxiv',
      ),
  },
]

export const GROUP_NAMES: Record<number, string> = {
  1: '技术资讯',
  2: 'AI 前沿',
}

export function getSource(id: string): Source {
  return SOURCES.find((s) => s.id === id) || SOURCES[0]
}
